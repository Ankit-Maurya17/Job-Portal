import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { jobsAPI } from '../utils/api';
import { Search, MapPin, Briefcase, DollarSign, Clock } from 'lucide-react';
import './Jobs.css';

const Jobs = () => {
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({
    search: '',
    jobType: '',
    location: '',
    experienceLevel: ''
  });

  useEffect(() => {
    fetchJobs();
  }, []);

  const fetchJobs = async (searchFilters = filters) => {
    try {
      setLoading(true);
      const response = await jobsAPI.getAllJobs(searchFilters);
      setJobs(response.data.jobs);
    } catch (error) {
      console.error('Error fetching jobs:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleFilterChange = (e) => {
    setFilters({
      ...filters,
      [e.target.name]: e.target.value
    });
  };

  const handleSearch = (e) => {
    e.preventDefault();
    fetchJobs(filters);
  };

  const handleReset = () => {
    const resetFilters = {
      search: '',
      jobType: '',
      location: '',
      experienceLevel: ''
    };
    setFilters(resetFilters);
    fetchJobs(resetFilters);
  };

  const formatSalary = (salaryRange) => {
    if (!salaryRange || (!salaryRange.min && !salaryRange.max)) {
      return 'Not specified';
    }
    const { min, max, currency = 'USD' } = salaryRange;
    if (min && max) {
      return `${currency} ${min.toLocaleString()} - ${max.toLocaleString()}`;
    }
    return `${currency} ${(min || max).toLocaleString()}`;
  };

  const getTimeAgo = (date) => {
    const seconds = Math.floor((new Date() - new Date(date)) / 1000);
    const intervals = {
      year: 31536000,
      month: 2592000,
      week: 604800,
      day: 86400,
      hour: 3600,
      minute: 60
    };

    for (const [unit, secondsInUnit] of Object.entries(intervals)) {
      const interval = Math.floor(seconds / secondsInUnit);
      if (interval >= 1) {
        return `${interval} ${unit}${interval > 1 ? 's' : ''} ago`;
      }
    }
    return 'Just now';
  };

  return (
    <div className="page-container">
      <div className="container">
        <h1 className="page-title">Browse Jobs</h1>
        <p className="page-subtitle">Find your perfect opportunity</p>

        <div className="search-section">
          <form onSubmit={handleSearch} className="search-form">
            <div className="search-input-group">
              <Search size={20} />
              <input
                type="text"
                name="search"
                placeholder="Job title, keywords, or company"
                value={filters.search}
                onChange={handleFilterChange}
              />
            </div>

            <div className="filters-row">
              <select name="jobType" value={filters.jobType} onChange={handleFilterChange}>
                <option value="">All Job Types</option>
                <option value="Full-time">Full-time</option>
                <option value="Part-time">Part-time</option>
                <option value="Contract">Contract</option>
                <option value="Internship">Internship</option>
                <option value="Freelance">Freelance</option>
              </select>

              <input
                type="text"
                name="location"
                placeholder="Location"
                value={filters.location}
                onChange={handleFilterChange}
              />

              <select name="experienceLevel" value={filters.experienceLevel} onChange={handleFilterChange}>
                <option value="">All Experience Levels</option>
                <option value="Entry Level">Entry Level</option>
                <option value="Mid Level">Mid Level</option>
                <option value="Senior Level">Senior Level</option>
                <option value="Executive">Executive</option>
              </select>
            </div>

            <div className="search-actions">
              <button type="submit" className="btn btn-primary">
                <Search size={18} />
                Search
              </button>
              <button type="button" onClick={handleReset} className="btn btn-secondary">
                Reset
              </button>
            </div>
          </form>
        </div>

        {loading ? (
          <div className="loading">Loading jobs...</div>
        ) : (
          <>
            <div className="jobs-count">
              <p>Found {jobs.length} job{jobs.length !== 1 ? 's' : ''}</p>
            </div>

            {jobs.length === 0 ? (
              <div className="no-results">
                <Briefcase size={64} />
                <h3>No jobs found</h3>
                <p>Try adjusting your search filters</p>
              </div>
            ) : (
              <div className="jobs-grid">
                {jobs.map((job) => (
                  <Link to={`/jobs/${job._id}`} key={job._id} className="job-card">
                    <div className="job-header">
                      <h3>{job.title}</h3>
                      <span className="badge badge-primary">{job.jobType}</span>
                    </div>

                    <p className="job-company">{job.company}</p>

                    <div className="job-details">
                      <div className="job-detail-item">
                        <MapPin size={16} />
                        <span>{job.location}</span>
                      </div>
                      <div className="job-detail-item">
                        <Briefcase size={16} />
                        <span>{job.experienceLevel}</span>
                      </div>
                      <div className="job-detail-item">
                        <DollarSign size={16} />
                        <span>{formatSalary(job.salaryRange)}</span>
                      </div>
                    </div>

                    <p className="job-description">{job.description.substring(0, 150)}...</p>

                    {job.skills && job.skills.length > 0 && (
                      <div className="job-skills">
                        {job.skills.slice(0, 3).map((skill, index) => (
                          <span key={index} className="skill-tag">{skill}</span>
                        ))}
                        {job.skills.length > 3 && (
                          <span className="skill-tag">+{job.skills.length - 3} more</span>
                        )}
                      </div>
                    )}

                    <div className="job-footer">
                      <div className="job-posted">
                        <Clock size={14} />
                        <span>{getTimeAgo(job.createdAt)}</span>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};

export default Jobs;
