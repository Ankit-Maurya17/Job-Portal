import React, { useEffect, useState } from 'react';
import { applicationsAPI } from '../utils/api';
import { FileText, User, Mail, Phone, MapPin, Calendar, Briefcase } from 'lucide-react';
import './AllApplications.css';

const AllApplications = () => {
  const [applications, setApplications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [filter, setFilter] = useState('all');

  useEffect(() => {
    fetchApplications();
  }, []);

  const fetchApplications = async () => {
    try {
      const response = await applicationsAPI.getAllEmployerApplications();
      setApplications(response.data.applications);
    } catch (error) {
      console.error('Error fetching applications:', error);
      setError('Failed to load applications');
    } finally {
      setLoading(false);
    }
  };

  const handleStatusUpdate = async (applicationId, newStatus) => {
    try {
      await applicationsAPI.updateApplicationStatus(applicationId, { status: newStatus });
      fetchApplications();
    } catch (error) {
      console.error('Error updating status:', error);
      alert('Failed to update application status');
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'pending': return 'badge-warning';
      case 'reviewed': return 'badge-primary';
      case 'shortlisted': return 'badge-primary';
      case 'accepted': return 'badge-success';
      case 'rejected': return 'badge-danger';
      default: return 'badge-primary';
    }
  };

  const filteredApplications = applications.filter(app => {
    if (filter === 'all') return true;
    return app.status === filter;
  });

  if (loading) {
    return <div className="loading">Loading applications...</div>;
  }

  return (
    <div className="page-container">
      <div className="container">
        <div className="applications-header">
          <div>
            <h1 className="page-title">All Applications</h1>
            <p className="page-subtitle">Manage all applications received for your job postings</p>
          </div>
        </div>

        {error && <div className="error-message">{error}</div>}

        <div className="filter-section">
          <button 
            className={`filter-btn ${filter === 'all' ? 'active' : ''}`}
            onClick={() => setFilter('all')}
          >
            All ({applications.length})
          </button>
          <button 
            className={`filter-btn ${filter === 'pending' ? 'active' : ''}`}
            onClick={() => setFilter('pending')}
          >
            Pending ({applications.filter(a => a.status === 'pending').length})
          </button>
          <button 
            className={`filter-btn ${filter === 'reviewed' ? 'active' : ''}`}
            onClick={() => setFilter('reviewed')}
          >
            Reviewed ({applications.filter(a => a.status === 'reviewed').length})
          </button>
          <button 
            className={`filter-btn ${filter === 'shortlisted' ? 'active' : ''}`}
            onClick={() => setFilter('shortlisted')}
          >
            Shortlisted ({applications.filter(a => a.status === 'shortlisted').length})
          </button>
          <button 
            className={`filter-btn ${filter === 'accepted' ? 'active' : ''}`}
            onClick={() => setFilter('accepted')}
          >
            Accepted ({applications.filter(a => a.status === 'accepted').length})
          </button>
        </div>

        {filteredApplications.length === 0 ? (
          <div className="no-applications">
            <FileText size={64} />
            <h3>No applications found</h3>
            <p>You haven't received any applications yet.</p>
          </div>
        ) : (
          <div className="applications-list">
            {filteredApplications.map((application) => (
              <div key={application._id} className="application-card">
                <div className="application-header">
                  <div className="applicant-info">
                    <div className="applicant-avatar">
                      <User size={32} />
                    </div>
                    <div>
                      <h3>{application.applicant?.name}</h3>
                      <p className="job-title">
                        <Briefcase size={16} />
                        Applied for: {application.job?.title}
                      </p>
                    </div>
                  </div>
                  <span className={`badge ${getStatusColor(application.status)}`}>
                    {application.status}
                  </span>
                </div>

                <div className="applicant-details">
                  <div className="detail-item">
                    <Mail size={16} />
                    <span>{application.applicant?.email}</span>
                  </div>
                  <div className="detail-item">
                    <Phone size={16} />
                    <span>{application.applicant?.phone || 'Not provided'}</span>
                  </div>
                  <div className="detail-item">
                    <MapPin size={16} />
                    <span>{application.applicant?.location || 'Not provided'}</span>
                  </div>
                  <div className="detail-item">
                    <Calendar size={16} />
                    <span>Applied: {new Date(application.appliedAt).toLocaleDateString()}</span>
                  </div>
                </div>

                {application.coverLetter && (
                  <div className="cover-letter">
                    <h4>Cover Letter:</h4>
                    <p>{application.coverLetter}</p>
                  </div>
                )}

                {application.applicant?.skills && application.applicant.skills.length > 0 && (
                  <div className="skills-section">
                    <h4>Skills:</h4>
                    <div className="skills-list">
                      {application.applicant.skills.map((skill, index) => (
                        <span key={index} className="skill-tag">{skill}</span>
                      ))}
                    </div>
                  </div>
                )}

                <div className="application-actions">
                  <select 
                    value={application.status}
                    onChange={(e) => handleStatusUpdate(application._id, e.target.value)}
                    className="status-select"
                  >
                    <option value="pending">Pending</option>
                    <option value="reviewed">Reviewed</option>
                    <option value="shortlisted">Shortlisted</option>
                    <option value="accepted">Accepted</option>
                    <option value="rejected">Rejected</option>
                  </select>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default AllApplications;
