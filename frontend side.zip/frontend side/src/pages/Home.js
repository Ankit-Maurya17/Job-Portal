import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Search, Briefcase, Users, TrendingUp, CheckCircle, Rocket, Shield, Zap, Award, Star, ArrowRight, Building2, MapPin } from 'lucide-react';
import './Home.css';

const Home = () => {
  const { isAuthenticated } = useAuth();

  return (
    <div className="home-page">
      <section className="hero-section">
        <div className="hero-background">
          <div className="hero-shape shape-1"></div>
          <div className="hero-shape shape-2"></div>
          <div className="hero-shape shape-3"></div>
        </div>
        <div className="container">
          <div className="hero-content">
            <div className="hero-badge">
              <Rocket size={16} />
              <span>#1 Job Portal Platform</span>
            </div>
            <h1 className="hero-title">
              Discover Your <span className="gradient-text">Dream Career</span><br />
              Opportunities
            </h1>
            <p className="hero-subtitle">
              Connect with 10,000+ companies and explore unlimited career possibilities.
              Your next big opportunity is just a click away.
            </p>
            <div className="hero-actions">
              {isAuthenticated ? (
                <>
                  <Link to="/jobs" className="btn btn-primary btn-large">
                    <Search size={20} />
                    Explore Jobs
                    <ArrowRight size={20} />
                  </Link>
                  <Link to="/dashboard" className="btn btn-secondary btn-large">
                    <Briefcase size={20} />
                    Dashboard
                  </Link>
                </>
              ) : (
                <>
                  <Link to="/register" className="btn btn-primary btn-large">
                    <Rocket size={20} />
                    Get Started Free
                    <ArrowRight size={20} />
                  </Link>
                  <Link to="/jobs" className="btn btn-secondary btn-large">
                    <Search size={20} />
                    Browse Jobs
                  </Link>
                </>
              )}
            </div>
            <div className="hero-stats">
              <div className="stat-item">
                <h3>50K+</h3>
                <p>Active Jobs</p>
              </div>
              <div className="stat-item">
                <h3>10K+</h3>
                <p>Companies</p>
              </div>
              <div className="stat-item">
                <h3>100K+</h3>
                <p>Job Seekers</p>
              </div>
              <div className="stat-item">
                <h3>95%</h3>
                <p>Success Rate</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="features-section">
        <div className="container">
          <div className="section-header">
            <span className="section-badge">Features</span>
            <h2 className="section-title">Why Choose Our Platform?</h2>
            <p className="section-description">
              Everything you need to find your perfect job or hire the best talent
            </p>
          </div>
          <div className="features-grid">
            <div className="feature-card">
              <div className="feature-icon-wrapper">
                <div className="feature-icon">
                  <Zap size={32} />
                </div>
              </div>
              <h3>Lightning Fast</h3>
              <p>Apply to jobs instantly with our one-click application system</p>
            </div>

            <div className="feature-card">
              <div className="feature-icon-wrapper">
                <div className="feature-icon">
                  <Shield size={32} />
                </div>
              </div>
              <h3>100% Secure</h3>
              <p>Your data is protected with enterprise-grade security</p>
            </div>

            <div className="feature-card">
              <div className="feature-icon-wrapper">
                <div className="feature-icon">
                  <Award size={32} />
                </div>
              </div>
              <h3>Top Companies</h3>
              <p>Connect with Fortune 500 and leading startups</p>
            </div>

            <div className="feature-card">
              <div className="feature-icon-wrapper">
                <div className="feature-icon">
                  <TrendingUp size={32} />
                </div>
              </div>
              <h3>Career Growth</h3>
              <p>Access resources and tools for professional development</p>
            </div>
          </div>
        </div>
      </section>

      <section className="how-it-works-section">
        <div className="container">
          <div className="section-header">
            <span className="section-badge">Process</span>
            <h2 className="section-title">Get Hired in 3 Simple Steps</h2>
            <p className="section-description">
              Start your journey to success with our streamlined process
            </p>
          </div>
          <div className="steps-container">
            <div className="step-card">
              <div className="step-number">01</div>
              <div className="step-icon">
                <Users size={40} />
              </div>
              <h3>Create Profile</h3>
              <p>Build your professional profile in minutes with our easy-to-use interface</p>
            </div>
            <div className="step-connector"></div>
            <div className="step-card">
              <div className="step-number">02</div>
              <div className="step-icon">
                <Search size={40} />
              </div>
              <h3>Find & Apply</h3>
              <p>Search thousands of jobs and apply with just one click</p>
            </div>
            <div className="step-connector"></div>
            <div className="step-card">
              <div className="step-number">03</div>
              <div className="step-icon">
                <Briefcase size={40} />
              </div>
              <h3>Get Hired</h3>
              <p>Connect with employers and start your dream career</p>
            </div>
          </div>
        </div>
      </section>

      <section className="dual-section">
        <div className="container">
          <div className="dual-grid">
            <div className="dual-card">
              <div className="dual-icon">
                <Users size={48} />
              </div>
              <h2>For Job Seekers</h2>
              <p className="dual-subtitle">Find your dream job with ease</p>
              <ul className="benefits-list">
                <li>
                  <CheckCircle size={20} />
                  <span>Access 50,000+ job listings</span>
                </li>
                <li>
                  <CheckCircle size={20} />
                  <span>One-click application process</span>
                </li>
                <li>
                  <CheckCircle size={20} />
                  <span>Personalized job recommendations</span>
                </li>
                <li>
                  <CheckCircle size={20} />
                  <span>Career development resources</span>
                </li>
              </ul>
              {!isAuthenticated && (
                <Link to="/register" className="btn btn-primary">
                  <Rocket size={20} />
                  Start Job Search
                </Link>
              )}
            </div>

            <div className="dual-card">
              <div className="dual-icon">
                <Building2 size={48} />
              </div>
              <h2>For Employers</h2>
              <p className="dual-subtitle">Hire top talent effortlessly</p>
              <ul className="benefits-list">
                <li>
                  <CheckCircle size={20} />
                  <span>Post unlimited job listings</span>
                </li>
                <li>
                  <CheckCircle size={20} />
                  <span>Access 100K+ qualified candidates</span>
                </li>
                <li>
                  <CheckCircle size={20} />
                  <span>Advanced applicant tracking</span>
                </li>
                <li>
                  <CheckCircle size={20} />
                  <span>Real-time application management</span>
                </li>
              </ul>
              {!isAuthenticated && (
                <Link to="/register" className="btn btn-primary">
                  <Briefcase size={20} />
                  Start Hiring
                </Link>
              )}
            </div>
          </div>
        </div>
      </section>

      <section className="cta-section">
        <div className="cta-background">
          <div className="cta-shape"></div>
        </div>
        <div className="container">
          <div className="cta-content">
            <div className="cta-icon">
              <Star size={48} />
            </div>
            <h2>Ready to Transform Your Career?</h2>
            <p>Join 100,000+ professionals who found their dream jobs with us</p>
            <div className="cta-actions">
              {!isAuthenticated ? (
                <>
                  <Link to="/register" className="btn btn-primary btn-large">
                    <Rocket size={20} />
                    Get Started Free
                    <ArrowRight size={20} />
                  </Link>
                  <Link to="/jobs" className="btn btn-secondary btn-large">
                    View All Jobs
                  </Link>
                </>
              ) : (
                <Link to="/jobs" className="btn btn-primary btn-large">
                  <Search size={20} />
                  Explore Opportunities
                  <ArrowRight size={20} />
                </Link>
              )}
            </div>
            <div className="cta-features">
              <div className="cta-feature">
                <CheckCircle size={20} />
                <span>No Credit Card Required</span>
              </div>
              <div className="cta-feature">
                <CheckCircle size={20} />
                <span>100% Free to Start</span>
              </div>
              <div className="cta-feature">
                <CheckCircle size={20} />
                <span>Cancel Anytime</span>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
