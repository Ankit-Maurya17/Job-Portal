import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { jobsAPI } from '../utils/api';
import { Briefcase, Plus, X } from 'lucide-react';
import './CreateJob.css';

const CreateJob = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    title: '',
    company: '',
    description: '',
    jobType: 'Full-time',
    location: '',
    experienceLevel: 'Entry Level',
    salaryMin: '',
    salaryMax: '',
    salaryCurrency: 'USD',
    applicationDeadline: '',
    status: 'active'
  });
  const [responsibilities, setResponsibilities] = useState(['']);
  const [qualifications, setQualifications] = useState(['']);
  const [skills, setSkills] = useState(['']);
  const [benefits, setBenefits] = useState(['']);
  const [message, setMessage] = useState({ type: '', text: '' });
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleArrayChange = (index, value, array, setArray) => {
    const newArray = [...array];
    newArray[index] = value;
    setArray(newArray);
  };

  const addArrayItem = (array, setArray) => {
    setArray([...array, '']);
  };

  const removeArrayItem = (index, array, setArray) => {
    setArray(array.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setMessage({ type: '', text: '' });

    try {
      const jobData = {
        ...formData,
        responsibilities: responsibilities.filter(r => r.trim()),
        qualifications: qualifications.filter(q => q.trim()),
        skills: skills.filter(s => s.trim()),
        benefits: benefits.filter(b => b.trim()),
        salaryRange: {
          min: formData.salaryMin ? Number(formData.salaryMin) : 0,
          max: formData.salaryMax ? Number(formData.salaryMax) : 0,
          currency: formData.salaryCurrency
        }
      };

      await jobsAPI.createJob(jobData);
      setMessage({ type: 'success', text: 'Job posted successfully!' });
      setTimeout(() => navigate('/dashboard'), 2000);
    } catch (error) {
      setMessage({ type: 'error', text: 'Failed to create job posting' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="page-container">
      <div className="container">
        <div className="create-job-container">
          <div className="create-job-header">
            <Briefcase size={48} />
            <h1 className="page-title">Post a New Job</h1>
            <p className="page-subtitle">Fill in the details to create a job listing</p>
          </div>

          {message.text && (
            <div className={message.type === 'error' ? 'error-message' : 'success-message'}>
              {message.text}
            </div>
          )}

          <form onSubmit={handleSubmit} className="create-job-form">
            <div className="form-section">
              <h2>Basic Information</h2>
              
              <div className="form-group">
                <label htmlFor="title">Job Title *</label>
                <input
                  type="text"
                  id="title"
                  name="title"
                  value={formData.title}
                  onChange={handleChange}
                  placeholder="e.g. Senior Software Engineer"
                  required
                />
              </div>

              <div className="form-group">
                <label htmlFor="company">Company Name *</label>
                <input
                  type="text"
                  id="company"
                  name="company"
                  value={formData.company}
                  onChange={handleChange}
                  placeholder="Your company name"
                  required
                />
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label htmlFor="jobType">Job Type *</label>
                  <select
                    id="jobType"
                    name="jobType"
                    value={formData.jobType}
                    onChange={handleChange}
                    required
                  >
                    <option value="Full-time">Full-time</option>
                    <option value="Part-time">Part-time</option>
                    <option value="Contract">Contract</option>
                    <option value="Internship">Internship</option>
                    <option value="Freelance">Freelance</option>
                  </select>
                </div>

                <div className="form-group">
                  <label htmlFor="experienceLevel">Experience Level *</label>
                  <select
                    id="experienceLevel"
                    name="experienceLevel"
                    value={formData.experienceLevel}
                    onChange={handleChange}
                    required
                  >
                    <option value="Entry Level">Entry Level</option>
                    <option value="Mid Level">Mid Level</option>
                    <option value="Senior Level">Senior Level</option>
                    <option value="Executive">Executive</option>
                  </select>
                </div>
              </div>

              <div className="form-group">
                <label htmlFor="location">Location *</label>
                <input
                  type="text"
                  id="location"
                  name="location"
                  value={formData.location}
                  onChange={handleChange}
                  placeholder="e.g. New York, NY or Remote"
                  required
                />
              </div>

              <div className="form-group">
                <label htmlFor="description">Job Description *</label>
                <textarea
                  id="description"
                  name="description"
                  value={formData.description}
                  onChange={handleChange}
                  placeholder="Provide a detailed description of the job..."
                  rows="6"
                  required
                />
              </div>
            </div>

            <div className="form-section">
              <h2>Salary Range</h2>
              
              <div className="form-row">
                <div className="form-group">
                  <label htmlFor="salaryMin">Minimum Salary</label>
                  <input
                    type="number"
                    id="salaryMin"
                    name="salaryMin"
                    value={formData.salaryMin}
                    onChange={handleChange}
                    placeholder="50000"
                  />
                </div>

                <div className="form-group">
                  <label htmlFor="salaryMax">Maximum Salary</label>
                  <input
                    type="number"
                    id="salaryMax"
                    name="salaryMax"
                    value={formData.salaryMax}
                    onChange={handleChange}
                    placeholder="80000"
                  />
                </div>

                <div className="form-group">
                  <label htmlFor="salaryCurrency">Currency</label>
                  <select
                    id="salaryCurrency"
                    name="salaryCurrency"
                    value={formData.salaryCurrency}
                    onChange={handleChange}
                  >
                    <option value="USD">USD</option>
                    <option value="EUR">EUR</option>
                    <option value="GBP">GBP</option>
                    <option value="INR">INR</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="form-section">
              <h2>Responsibilities</h2>
              {responsibilities.map((resp, index) => (
                <div key={index} className="array-input-group">
                  <input
                    type="text"
                    value={resp}
                    onChange={(e) => handleArrayChange(index, e.target.value, responsibilities, setResponsibilities)}
                    placeholder="Enter a responsibility"
                  />
                  {responsibilities.length > 1 && (
                    <button
                      type="button"
                      onClick={() => removeArrayItem(index, responsibilities, setResponsibilities)}
                      className="btn-icon btn-danger"
                    >
                      <X size={18} />
                    </button>
                  )}
                </div>
              ))}
              <button
                type="button"
                onClick={() => addArrayItem(responsibilities, setResponsibilities)}
                className="btn btn-secondary btn-small"
              >
                <Plus size={18} />
                Add Responsibility
              </button>
            </div>

            <div className="form-section">
              <h2>Qualifications</h2>
              {qualifications.map((qual, index) => (
                <div key={index} className="array-input-group">
                  <input
                    type="text"
                    value={qual}
                    onChange={(e) => handleArrayChange(index, e.target.value, qualifications, setQualifications)}
                    placeholder="Enter a qualification"
                  />
                  {qualifications.length > 1 && (
                    <button
                      type="button"
                      onClick={() => removeArrayItem(index, qualifications, setQualifications)}
                      className="btn-icon btn-danger"
                    >
                      <X size={18} />
                    </button>
                  )}
                </div>
              ))}
              <button
                type="button"
                onClick={() => addArrayItem(qualifications, setQualifications)}
                className="btn btn-secondary btn-small"
              >
                <Plus size={18} />
                Add Qualification
              </button>
            </div>

            <div className="form-section">
              <h2>Required Skills</h2>
              {skills.map((skill, index) => (
                <div key={index} className="array-input-group">
                  <input
                    type="text"
                    value={skill}
                    onChange={(e) => handleArrayChange(index, e.target.value, skills, setSkills)}
                    placeholder="Enter a skill"
                  />
                  {skills.length > 1 && (
                    <button
                      type="button"
                      onClick={() => removeArrayItem(index, skills, setSkills)}
                      className="btn-icon btn-danger"
                    >
                      <X size={18} />
                    </button>
                  )}
                </div>
              ))}
              <button
                type="button"
                onClick={() => addArrayItem(skills, setSkills)}
                className="btn btn-secondary btn-small"
              >
                <Plus size={18} />
                Add Skill
              </button>
            </div>

            <div className="form-section">
              <h2>Benefits</h2>
              {benefits.map((benefit, index) => (
                <div key={index} className="array-input-group">
                  <input
                    type="text"
                    value={benefit}
                    onChange={(e) => handleArrayChange(index, e.target.value, benefits, setBenefits)}
                    placeholder="Enter a benefit"
                  />
                  {benefits.length > 1 && (
                    <button
                      type="button"
                      onClick={() => removeArrayItem(index, benefits, setBenefits)}
                      className="btn-icon btn-danger"
                    >
                      <X size={18} />
                    </button>
                  )}
                </div>
              ))}
              <button
                type="button"
                onClick={() => addArrayItem(benefits, setBenefits)}
                className="btn btn-secondary btn-small"
              >
                <Plus size={18} />
                Add Benefit
              </button>
            </div>

            <div className="form-section">
              <h2>Additional Details</h2>
              
              <div className="form-group">
                <label htmlFor="applicationDeadline">Application Deadline</label>
                <input
                  type="date"
                  id="applicationDeadline"
                  name="applicationDeadline"
                  value={formData.applicationDeadline}
                  onChange={handleChange}
                />
              </div>

              <div className="form-group">
                <label htmlFor="status">Status</label>
                <select
                  id="status"
                  name="status"
                  value={formData.status}
                  onChange={handleChange}
                >
                  <option value="active">Active</option>
                  <option value="draft">Draft</option>
                </select>
              </div>
            </div>

            <div className="form-actions-horizontal">
              <button type="submit" className="btn btn-primary" disabled={loading}>
                {loading ? 'Creating...' : 'Post Job'}
              </button>
              <button type="button" onClick={() => navigate('/dashboard')} className="btn btn-secondary">
                Cancel
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default CreateJob;
