import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { jobsAPI, applicationsAPI } from '../utils/api';
import { MapPin, Briefcase, DollarSign, Calendar, Building, CheckCircle, ArrowLeft } from 'lucide-react';
import './JobDetails.css';

const JobDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user, isJobSeeker, isAuthenticated } = useAuth();
  const [job, setJob] = useState(null);
  const [loading, setLoading] = useState(true);
  const [applying, setApplying] = useState(false);
  const [showApplicationForm, setShowApplicationForm] = useState(false);
  const [applicationData, setApplicationData] = useState({
    coverLetter: '',
    resume: user?.resume || ''
  });
  const [message, setMessage] = useState({ type: '', text: '' });

  useEffect(() => {
    fetchJobDetails();
  }, [id]);

  const fetchJobDetails = async () => {
    try {
      const response = await jobsAPI.getJobById(id);
      setJob(response.data.job);
    } catch (error) {
      console.error('Error fetching job details:', error);
      setMessage({ type: 'error', text: 'Failed to load job details' });
    } finally {
      setLoading(false);
    }
  };

  const handleApplicationChange = (e) => {
    setApplicationData({
      ...applicationData,
      [e.target.name]: e.target.value
    });
  };

  const handleApply = async (e) => {
    e.preventDefault();
    
    if (!isAuthenticated) {
      navigate('/login');
      return;
    }

    if (!applicationData.resume) {
      setMessage({ type: 'error', text: 'Please provide your resume URL or update your profile' });
      return;
    }

    setApplying(true);
    setMessage({ type: '', text: '' });

    try {
      await applicationsAPI.createApplication({
        jobId: id,
        ...applicationData
      });
      setMessage({ type: 'success', text: 'Application submitted successfully!' });
      setShowApplicationForm(false);
    } catch (error) {
      const errorMsg = error.response?.data?.message || 'Failed to submit application';
      setMessage({ type: 'error', text: errorMsg });
    } finally {
      setApplying(false);
    }
  };

  if (loading) {
    return <div className="loading">Loading job details...</div>;
  }

  if (!job) {
    return (
      <div className="page-container">
        <div className="container">
          <div className="error-message">Job not found</div>
        </div>
      </div>
    );
  }

  const formatSalary = (salaryRange) => {
    if (!salaryRange || (!salaryRange.min && !salaryRange.max)) {
      return 'Not specified';
    }
    const { min, max, currency = 'USD' } = salaryRange;
    if (min && max) {
      return `${currency} ${min.toLocaleString()} - ${max.toLocaleString()}`;
    }
    return `${currency} ${(min || max).toLocaleString()}`;
  };

  return (
    <div className="page-container">
      <div className="container">
        <button onClick={() => navigate(-1)} className="back-button">
          <ArrowLeft size={20} />
          Back
        </button>

        {message.text && (
          <div className={message.type === 'error' ? 'error-message' : 'success-message'}>
            {message.text}
          </div>
        )}

        <div className="job-details-container">
          <div className="job-details-main">
            <div className="job-details-header">
              <div>
                <h1>{job.title}</h1>
                <p className="job-company-name">
                  <Building size={20} />
                  {job.company}
                </p>
              </div>
              <span className="badge badge-primary">{job.jobType}</span>
            </div>

            <div className="job-meta">
              <div className="meta-item">
                <MapPin size={18} />
                <span>{job.location}</span>
              </div>
              <div className="meta-item">
                <Briefcase size={18} />
                <span>{job.experienceLevel}</span>
              </div>
              <div className="meta-item">
                <DollarSign size={18} />
                <span>{formatSalary(job.salaryRange)}</span>
              </div>
              {job.applicationDeadline && (
                <div className="meta-item">
                  <Calendar size={18} />
                  <span>Deadline: {new Date(job.applicationDeadline).toLocaleDateString()}</span>
                </div>
              )}
            </div>

            <div className="job-section">
              <h2>Job Description</h2>
              <p>{job.description}</p>
            </div>

            {job.responsibilities && job.responsibilities.length > 0 && (
              <div className="job-section">
                <h2>Responsibilities</h2>
                <ul>
                  {job.responsibilities.map((item, index) => (
                    <li key={index}>
                      <CheckCircle size={18} />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {job.qualifications && job.qualifications.length > 0 && (
              <div className="job-section">
                <h2>Qualifications</h2>
                <ul>
                  {job.qualifications.map((item, index) => (
                    <li key={index}>
                      <CheckCircle size={18} />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {job.skills && job.skills.length > 0 && (
              <div className="job-section">
                <h2>Required Skills</h2>
                <div className="skills-list">
                  {job.skills.map((skill, index) => (
                    <span key={index} className="skill-badge">{skill}</span>
                  ))}
                </div>
              </div>
            )}

            {job.benefits && job.benefits.length > 0 && (
              <div className="job-section">
                <h2>Benefits</h2>
                <ul>
                  {job.benefits.map((item, index) => (
                    <li key={index}>
                      <CheckCircle size={18} />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>

          <div className="job-details-sidebar">
            <div className="sidebar-card">
              <h3>About the Company</h3>
              <p className="company-name">{job.company}</p>
              {job.postedBy?.companyDescription && (
                <p className="company-description">{job.postedBy.companyDescription}</p>
              )}
              {job.postedBy?.email && (
                <p className="company-contact">
                  <strong>Contact:</strong> {job.postedBy.email}
                </p>
              )}
            </div>

            {isJobSeeker && (
              <div className="sidebar-card">
                {!showApplicationForm ? (
                  <button onClick={() => setShowApplicationForm(true)} className="btn btn-primary btn-block">
                    Apply Now
                  </button>
                ) : (
                  <form onSubmit={handleApply} className="application-form">
                    <h3>Apply for this position</h3>
                    
                    <div className="form-group">
                      <label htmlFor="resume">Resume URL</label>
                      <input
                        type="url"
                        id="resume"
                        name="resume"
                        value={applicationData.resume}
                        onChange={handleApplicationChange}
                        placeholder="https://..."
                        required
                      />
                    </div>

                    <div className="form-group">
                      <label htmlFor="coverLetter">Cover Letter (Optional)</label>
                      <textarea
                        id="coverLetter"
                        name="coverLetter"
                        value={applicationData.coverLetter}
                        onChange={handleApplicationChange}
                        placeholder="Tell us why you're a great fit..."
                        rows="6"
                      />
                    </div>

                    <div className="form-actions">
                      <button type="submit" className="btn btn-primary" disabled={applying}>
                        {applying ? 'Submitting...' : 'Submit Application'}
                      </button>
                      <button 
                        type="button" 
                        onClick={() => setShowApplicationForm(false)} 
                        className="btn btn-secondary"
                      >
                        Cancel
                      </button>
                    </div>
                  </form>
                )}
              </div>
            )}

            {!isAuthenticated && (
              <div className="sidebar-card">
                <p>Please login to apply for this job</p>
                <button onClick={() => navigate('/login')} className="btn btn-primary btn-block">
                  Login to Apply
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default JobDetails;
