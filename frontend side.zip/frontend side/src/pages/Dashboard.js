import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { jobsAPI, applicationsAPI } from '../utils/api';
import { Briefcase, FileText, PlusCircle, TrendingUp, CheckCircle, Clock, XCircle, Eye, Users, Calendar, ArrowRight, Sparkles, Target, Award } from 'lucide-react';
import './Dashboard.css';

const Dashboard = () => {
  const { user, isEmployer } = useAuth();
  const [stats, setStats] = useState({
    totalJobs: 0,
    totalApplications: 0,
    activeJobs: 0,
    pendingApplications: 0
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      if (isEmployer) {
        const jobsResponse = await jobsAPI.getEmployerJobs();
        const jobs = jobsResponse.data.jobs;
        const activeJobs = jobs.filter(job => job.status === 'active').length;
        
        let totalApplications = 0;
        jobs.forEach(job => {
          totalApplications += job.applicants.length;
        });

        setStats({
          totalJobs: jobs.length,
          activeJobs,
          totalApplications,
          pendingApplications: totalApplications
        });
      } else {
        const applicationsResponse = await applicationsAPI.getMyApplications();
        const applications = applicationsResponse.data.applications;
        const pendingApplications = applications.filter(app => app.status === 'pending').length;

        setStats({
          totalApplications: applications.length,
          pendingApplications,
          totalJobs: 0,
          activeJobs: 0
        });
      }
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <div className="loading">Loading dashboard...</div>;
  }

  return (
    <div className="page-container dashboard-page">
      <div className="container">
        {/* Welcome Header */}
        <div className="dashboard-welcome">
          <div className="welcome-content">
            <div className="welcome-badge">
              <Sparkles size={16} />
              <span>{isEmployer ? 'Employer Dashboard' : 'Job Seeker Dashboard'}</span>
            </div>
            <h1 className="welcome-title">
              Welcome back, <span className="gradient-text">{user?.name}</span>! 👋
            </h1>
            <p className="welcome-subtitle">
              {isEmployer 
                ? 'Manage your job postings and find the perfect candidates' 
                : 'Track your applications and discover new opportunities'}
            </p>
          </div>
          <div className="welcome-illustration">
            {isEmployer ? <Target size={80} /> : <Award size={80} />}
          </div>
        </div>

        {/* Stats Grid */}
        <div className="stats-grid">
          {isEmployer ? (
            <>
              <div className="stat-card stat-card-primary">
                <div className="stat-header">
                  <div className="stat-icon">
                    <Briefcase size={28} />
                  </div>
                  <span className="stat-badge">Total</span>
                </div>
                <div className="stat-content">
                  <h3>{stats.totalJobs}</h3>
                  <p>Jobs Posted</p>
                </div>
                <div className="stat-footer">
                  <TrendingUp size={16} />
                  <span>All time</span>
                </div>
              </div>

              <div className="stat-card stat-card-success">
                <div className="stat-header">
                  <div className="stat-icon">
                    <CheckCircle size={28} />
                  </div>
                  <span className="stat-badge">Active</span>
                </div>
                <div className="stat-content">
                  <h3>{stats.activeJobs}</h3>
                  <p>Active Jobs</p>
                </div>
                <div className="stat-footer">
                  <Eye size={16} />
                  <span>Live now</span>
                </div>
              </div>

              <Link to="/all-applications" className="stat-card stat-card-warning stat-card-link">
                <div className="stat-header">
                  <div className="stat-icon">
                    <Users size={28} />
                  </div>
                  <span className="stat-badge">Received</span>
                </div>
                <div className="stat-content">
                  <h3>{stats.totalApplications}</h3>
                  <p>Applications</p>
                </div>
                <div className="stat-footer">
                  <ArrowRight size={16} />
                  <span>View all</span>
                </div>
              </Link>

              <div className="stat-card stat-card-info">
                <div className="stat-header">
                  <div className="stat-icon">
                    <Clock size={28} />
                  </div>
                  <span className="stat-badge">Pending</span>
                </div>
                <div className="stat-content">
                  <h3>{stats.pendingApplications}</h3>
                  <p>To Review</p>
                </div>
                <div className="stat-footer">
                  <Calendar size={16} />
                  <span>Action needed</span>
                </div>
              </div>
            </>
          ) : (
            <>
              <div className="stat-card stat-card-primary">
                <div className="stat-header">
                  <div className="stat-icon">
                    <FileText size={28} />
                  </div>
                  <span className="stat-badge">Total</span>
                </div>
                <div className="stat-content">
                  <h3>{stats.totalApplications}</h3>
                  <p>Applications</p>
                </div>
                <div className="stat-footer">
                  <TrendingUp size={16} />
                  <span>Submitted</span>
                </div>
              </div>

              <div className="stat-card stat-card-warning">
                <div className="stat-header">
                  <div className="stat-icon">
                    <Clock size={28} />
                  </div>
                  <span className="stat-badge">Pending</span>
                </div>
                <div className="stat-content">
                  <h3>{stats.pendingApplications}</h3>
                  <p>Under Review</p>
                </div>
                <div className="stat-footer">
                  <Eye size={16} />
                  <span>Waiting</span>
                </div>
              </div>

              <div className="stat-card stat-card-success">
                <div className="stat-header">
                  <div className="stat-icon">
                    <CheckCircle size={28} />
                  </div>
                  <span className="stat-badge">Success</span>
                </div>
                <div className="stat-content">
                  <h3>{stats.totalApplications - stats.pendingApplications}</h3>
                  <p>Reviewed</p>
                </div>
                <div className="stat-footer">
                  <Award size={16} />
                  <span>Processed</span>
                </div>
              </div>
            </>
          )}
        </div>

        {/* Quick Actions */}
        <div className="dashboard-section">
          <div className="section-header-inline">
            <h2 className="section-title-small">Quick Actions</h2>
            <p className="section-subtitle-small">Get started with these actions</p>
          </div>
          
          <div className="action-cards">
            {isEmployer ? (
              <>
                <Link to="/create-job" className="action-card action-card-featured">
                  <div className="action-card-icon">
                    <PlusCircle size={40} />
                  </div>
                  <div className="action-card-content">
                    <h3>Post a New Job</h3>
                    <p>Create and publish a new job listing to attract top talent</p>
                  </div>
                  <div className="action-card-arrow">
                    <ArrowRight size={24} />
                  </div>
                </Link>

                <Link to="/jobs" className="action-card">
                  <div className="action-card-icon">
                    <Briefcase size={40} />
                  </div>
                  <div className="action-card-content">
                    <h3>Manage Jobs</h3>
                    <p>View, edit, and manage all your job postings</p>
                  </div>
                  <div className="action-card-arrow">
                    <ArrowRight size={24} />
                  </div>
                </Link>

                <Link to="/all-applications" className="action-card">
                  <div className="action-card-icon">
                    <Users size={40} />
                  </div>
                  <div className="action-card-content">
                    <h3>View Applications</h3>
                    <p>Review and manage candidate applications</p>
                  </div>
                  <div className="action-card-arrow">
                    <ArrowRight size={24} />
                  </div>
                </Link>
              </>
            ) : (
              <>
                <Link to="/jobs" className="action-card action-card-featured">
                  <div className="action-card-icon">
                    <Briefcase size={40} />
                  </div>
                  <div className="action-card-content">
                    <h3>Browse Jobs</h3>
                    <p>Discover thousands of job opportunities that match your skills</p>
                  </div>
                  <div className="action-card-arrow">
                    <ArrowRight size={24} />
                  </div>
                </Link>

                <Link to="/my-applications" className="action-card">
                  <div className="action-card-icon">
                    <FileText size={40} />
                  </div>
                  <div className="action-card-content">
                    <h3>My Applications</h3>
                    <p>Track the status of all your job applications</p>
                  </div>
                  <div className="action-card-arrow">
                    <ArrowRight size={24} />
                  </div>
                </Link>

                <Link to="/profile" className="action-card">
                  <div className="action-card-icon">
                    <Award size={40} />
                  </div>
                  <div className="action-card-content">
                    <h3>Update Profile</h3>
                    <p>Keep your profile updated to attract employers</p>
                  </div>
                  <div className="action-card-arrow">
                    <ArrowRight size={24} />
                  </div>
                </Link>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
