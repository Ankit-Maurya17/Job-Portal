import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Mail, ArrowLeft, Key } from 'lucide-react';
import { authAPI } from '../utils/api';
import './Auth.css';

const ForgotPassword = () => {
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [step, setStep] = useState(1); // 1: email input, 2: success message
  
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setMessage('');
    setLoading(true);

    try {
      const response = await authAPI.forgotPassword({ email });
      
      if (response.data.success) {
        setMessage('Password reset link has been sent to your email. Please check your inbox.');
        setStep(2);
      } else {
        setError(response.data.message || 'Failed to send reset link. Please try again.');
      }
    } catch (error) {
      const message = error.response?.data?.message || 'Network error. Please try again.';
      setError(message);
    }

    setLoading(false);
  };

  return (
    <div className="auth-page">
      <div className="auth-container">
        <div className="auth-card">
          <div className="auth-header">
            <Key size={48} className="auth-icon" />
            <h1>Forgot Password</h1>
            <p>
              {step === 1 
                ? "Enter your email address and we'll send you a link to reset your password"
                : "Check your email for reset instructions"
              }
            </p>
          </div>

          {error && <div className="error-message">{error}</div>}
          {message && <div className="success-message">{message}</div>}

          {step === 1 ? (
            <form onSubmit={handleSubmit} className="auth-form">
              <div className="form-group">
                <label htmlFor="email">
                  <Mail size={18} />
                  Email Address
                </label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter your registered email"
                  required
                />
              </div>

              <button 
                type="submit" 
                className="btn btn-primary btn-block" 
                disabled={loading}
              >
                {loading ? 'Sending...' : 'Send Reset Link'}
              </button>
            </form>
          ) : (
            <div className="auth-form">
              <div className="success-details">
                <p>We've sent a password reset link to:</p>
                <p className="email-highlight">{email}</p>
                <p>Please check your email and follow the instructions to reset your password.</p>
                <p className="note">
                  <strong>Note:</strong> If you don't receive the email within a few minutes, 
                  please check your spam folder.
                </p>
              </div>
              
              <button 
                className="btn btn-secondary btn-block"
                onClick={() => {
                  setStep(1);
                  setEmail('');
                  setMessage('');
                }}
              >
                Send Again
              </button>
            </div>
          )}

          <div className="auth-footer">
            <p>
              <Link to="/login" className="back-link">
                <ArrowLeft size={16} />
                Back to Login
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ForgotPassword;
