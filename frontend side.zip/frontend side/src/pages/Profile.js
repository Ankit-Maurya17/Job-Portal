import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { authAPI } from '../utils/api';
import { User, Mail, Phone, MapPin, Briefcase, Award } from 'lucide-react';
import './Profile.css';

const Profile = () => {
  const { user, updateUser } = useAuth();
  const [editing, setEditing] = useState(false);
  const [formData, setFormData] = useState({
    name: user?.name || '',
    phone: user?.phone || '',
    location: user?.location || '',
    skills: user?.skills?.join(', ') || '',
    experience: user?.experience || '',
    resume: user?.resume || '',
    company: user?.company || '',
    companyDescription: user?.companyDescription || ''
  });
  const [message, setMessage] = useState({ type: '', text: '' });
  const [loading, setLoading] = useState(false);
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [passwordData, setPasswordData] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });
  const [passwordMessage, setPasswordMessage] = useState({ type: '', text: '' });
  const [passwordLoading, setPasswordLoading] = useState(false);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handlePasswordChange = (e) => {
    setPasswordData({
      ...passwordData,
      [e.target.name]: e.target.value
    });
  };

  const handlePasswordSubmit = async (e) => {
    e.preventDefault();
    setPasswordLoading(true);
    setPasswordMessage({ type: '', text: '' });

    // Validation
    if (!passwordData.currentPassword || !passwordData.newPassword || !passwordData.confirmPassword) {
      setPasswordMessage({ type: 'error', text: 'All password fields are required' });
      setPasswordLoading(false);
      return;
    }

    if (passwordData.newPassword !== passwordData.confirmPassword) {
      setPasswordMessage({ type: 'error', text: 'New password and confirm password do not match' });
      setPasswordLoading(false);
      return;
    }

    if (passwordData.newPassword.length < 6) {
      setPasswordMessage({ type: 'error', text: 'New password must be at least 6 characters long' });
      setPasswordLoading(false);
      return;
    }

    try {
      const response = await authAPI.updatePassword({
        currentPassword: passwordData.currentPassword,
        newPassword: passwordData.newPassword
      });
      setPasswordMessage({ type: 'success', text: 'Password updated successfully!' });
      setPasswordData({
        currentPassword: '',
        newPassword: '',
        confirmPassword: ''
      });
      setTimeout(() => {
        setShowPasswordModal(false);
        setPasswordMessage({ type: '', text: '' });
      }, 2000);
    } catch (error) {
      setPasswordMessage({ type: 'error', text: error.response?.data?.message || 'Failed to update password' });
    } finally {
      setPasswordLoading(false);
    }
  };

  const handlePasswordModalClose = () => {
    setShowPasswordModal(false);
    setPasswordData({
      currentPassword: '',
      newPassword: '',
      confirmPassword: ''
    });
    setPasswordMessage({ type: '', text: '' });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setMessage({ type: '', text: '' });

    try {
      const updateData = {
        ...formData,
        skills: formData.skills.split(',').map(s => s.trim()).filter(s => s)
      };

      const response = await authAPI.updateProfile(updateData);
      updateUser(response.data.user);
      setMessage({ type: 'success', text: 'Profile updated successfully!' });
      setEditing(false);
    } catch (error) {
      setMessage({ type: 'error', text: 'Failed to update profile' });
    } finally {
      setLoading(false);
    }
  };

  const handleCancel = () => {
    setFormData({
      name: user?.name || '',
      phone: user?.phone || '',
      location: user?.location || '',
      skills: user?.skills?.join(', ') || '',
      experience: user?.experience || '',
      resume: user?.resume || '',
      company: user?.company || '',
      companyDescription: user?.companyDescription || ''
    });
    setEditing(false);
    setMessage({ type: '', text: '' });
  };

  return (
    <div className="page-container">
      <div className="container">
        <div className="profile-container">
          <div className="profile-header">
            <div className="profile-avatar">
              <User size={64} />
            </div>
            <div className="profile-info">
              <h1>{user?.name}</h1>
              <p className="profile-role">{user?.role === 'employer' ? 'Employer' : 'Job Seeker'}</p>
            </div>
          </div>

          {message.text && (
            <div className={message.type === 'error' ? 'error-message' : 'success-message'}>
              {message.text}
            </div>
          )}

          <div className="profile-content">
            {!editing ? (
              <div className="profile-view">
                <div className="profile-section">
                  <h2>Contact Information</h2>
                  <div className="info-grid">
                    <div className="info-item">
                      <Mail size={20} />
                      <div>
                        <label>Email</label>
                        <p>{user?.email}</p>
                      </div>
                    </div>
                    <div className="info-item">
                      <Phone size={20} />
                      <div>
                        <label>Phone</label>
                        <p>{user?.phone || 'Not provided'}</p>
                      </div>
                    </div>
                    <div className="info-item">
                      <MapPin size={20} />
                      <div>
                        <label>Location</label>
                        <p>{user?.location || 'Not provided'}</p>
                      </div>
                    </div>
                  </div>
                </div>

                {user?.role === 'employer' ? (
                  <div className="profile-section">
                    <h2>Company Information</h2>
                    <div className="info-grid">
                      <div className="info-item">
                        <Briefcase size={20} />
                        <div>
                          <label>Company Name</label>
                          <p>{user?.company || 'Not provided'}</p>
                        </div>
                      </div>
                    </div>
                    {user?.companyDescription && (
                      <div className="info-item">
                        <div>
                          <label>Company Description</label>
                          <p>{user.companyDescription}</p>
                        </div>
                      </div>
                    )}
                  </div>
                ) : (
                  <>
                    <div className="profile-section">
                      <h2>Professional Information</h2>
                      <div className="info-item">
                        <Award size={20} />
                        <div>
                          <label>Experience</label>
                          <p>{user?.experience || 'Not provided'}</p>
                        </div>
                      </div>
                      <div className="info-item">
                        <Briefcase size={20} />
                        <div>
                          <label>Resume</label>
                          <p>{user?.resume ? <a href={user.resume} target="_blank" rel="noopener noreferrer">View Resume</a> : 'Not provided'}</p>
                        </div>
                      </div>
                    </div>

                    {user?.skills && user.skills.length > 0 && (
                      <div className="profile-section">
                        <h2>Skills</h2>
                        <div className="skills-display">
                          {user.skills.map((skill, index) => (
                            <span key={index} className="skill-tag">{skill}</span>
                          ))}
                        </div>
                      </div>
                    )}
                  </>
                )}

                <button onClick={() => setEditing(true)} className="btn btn-primary">
                  Edit Profile
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="profile-edit">
                <div className="profile-section">
                  <h2>Basic Information</h2>
                  <div className="form-group">
                    <label htmlFor="name">Full Name</label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      required
                    />
                  </div>

                  <div className="form-group">
                    <label htmlFor="phone">Phone Number</label>
                    <input
                      type="tel"
                      id="phone"
                      name="phone"
                      value={formData.phone}
                      onChange={handleChange}
                    />
                  </div>

                  <div className="form-group">
                    <label htmlFor="location">Location</label>
                    <input
                      type="text"
                      id="location"
                      name="location"
                      value={formData.location}
                      onChange={handleChange}
                      placeholder="City, Country"
                    />
                  </div>
                </div>

                {user?.role === 'employer' ? (
                  <div className="profile-section">
                    <h2>Company Information</h2>
                    <div className="form-group">
                      <label htmlFor="company">Company Name</label>
                      <input
                        type="text"
                        id="company"
                        name="company"
                        value={formData.company}
                        onChange={handleChange}
                      />
                    </div>

                    <div className="form-group">
                      <label htmlFor="companyDescription">Company Description</label>
                      <textarea
                        id="companyDescription"
                        name="companyDescription"
                        value={formData.companyDescription}
                        onChange={handleChange}
                        rows="4"
                        placeholder="Tell us about your company..."
                      />
                    </div>
                  </div>
                ) : (
                  <div className="profile-section">
                    <h2>Professional Information</h2>
                    <div className="form-group">
                      <label htmlFor="experience">Experience</label>
                      <textarea
                        id="experience"
                        name="experience"
                        value={formData.experience}
                        onChange={handleChange}
                        rows="4"
                        placeholder="Describe your work experience..."
                      />
                    </div>

                    <div className="form-group">
                      <label htmlFor="skills">Skills (comma-separated)</label>
                      <input
                        type="text"
                        id="skills"
                        name="skills"
                        value={formData.skills}
                        onChange={handleChange}
                        placeholder="JavaScript, React, Node.js, etc."
                      />
                    </div>

                    <div className="form-group">
                      <label htmlFor="resume">Resume URL</label>
                      <input
                        type="url"
                        id="resume"
                        name="resume"
                        value={formData.resume}
                        onChange={handleChange}
                        placeholder="https://..."
                      />
                    </div>
                  </div>
                )}

                <div className="form-actions-horizontal">
                  <button type="submit" className="btn btn-primary" disabled={loading}>
                    {loading ? 'Saving...' : 'Save Changes'}
                  </button>
                  <button type="button" onClick={handleCancel} className="btn btn-secondary">
                    Cancel
                  </button>
                  <button type="button" onClick={() => setShowPasswordModal(true)} className="btn btn-warning">
                    Change Password
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      </div>

      {/* Password Change Modal */}
      {showPasswordModal && (
        <div className="modal-overlay">
          <div className="modal">
            <div className="modal-header">
              <h2>Change Password</h2>
              <button onClick={handlePasswordModalClose} className="modal-close">&times;</button>
            </div>
            <form onSubmit={handlePasswordSubmit} className="modal-content">
              {passwordMessage.text && (
                <div className={passwordMessage.type === 'error' ? 'error-message' : 'success-message'}>
                  {passwordMessage.text}
                </div>
              )}
              
              <div className="form-group">
                <label htmlFor="currentPassword">Old Password</label>
                <input
                  type="password"
                  id="currentPassword"
                  name="currentPassword"
                  value={passwordData.currentPassword}
                  onChange={handlePasswordChange}
                  required
                />
              </div>

              <div className="form-group">
                <label htmlFor="newPassword">New Password</label>
                <input
                  type="password"
                  id="newPassword"
                  name="newPassword"
                  value={passwordData.newPassword}
                  onChange={handlePasswordChange}
                  required
                />
              </div>

              <div className="form-group">
                <label htmlFor="confirmPassword">Confirm New Password</label>
                <input
                  type="password"
                  id="confirmPassword"
                  name="confirmPassword"
                  value={passwordData.confirmPassword}
                  onChange={handlePasswordChange}
                  required
                />
              </div>

              <div className="modal-actions">
                <button type="submit" className="btn btn-primary" disabled={passwordLoading}>
                  {passwordLoading ? 'Updating...' : 'Update Password'}
                </button>
                <button type="button" onClick={handlePasswordModalClose} className="btn btn-secondary">
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Profile;
