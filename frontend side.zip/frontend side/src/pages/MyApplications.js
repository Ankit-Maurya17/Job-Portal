import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { applicationsAPI } from '../utils/api';
import { FileText, Briefcase, MapPin, Clock, CheckCircle, XCircle, AlertCircle } from 'lucide-react';
import './MyApplications.css';

const MyApplications = () => {
  const [applications, setApplications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');

  useEffect(() => {
    fetchApplications();
  }, []);

  const fetchApplications = async () => {
    try {
      const response = await applicationsAPI.getMyApplications();
      setApplications(response.data.applications);
    } catch (error) {
      console.error('Error fetching applications:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'accepted':
        return <CheckCircle size={20} color="#10b981" />;
      case 'rejected':
        return <XCircle size={20} color="#ef4444" />;
      case 'shortlisted':
        return <CheckCircle size={20} color="#3b82f6" />;
      case 'reviewed':
        return <AlertCircle size={20} color="#f59e0b" />;
      default:
        return <Clock size={20} color="#6b7280" />;
    }
  };

  const getStatusBadgeClass = (status) => {
    switch (status) {
      case 'accepted':
        return 'badge-success';
      case 'rejected':
        return 'badge-danger';
      case 'shortlisted':
        return 'badge-primary';
      case 'reviewed':
        return 'badge-warning';
      default:
        return 'badge-warning';
    }
  };

  const getTimeAgo = (date) => {
    const seconds = Math.floor((new Date() - new Date(date)) / 1000);
    const intervals = {
      year: 31536000,
      month: 2592000,
      week: 604800,
      day: 86400,
      hour: 3600,
      minute: 60
    };

    for (const [unit, secondsInUnit] of Object.entries(intervals)) {
      const interval = Math.floor(seconds / secondsInUnit);
      if (interval >= 1) {
        return `${interval} ${unit}${interval > 1 ? 's' : ''} ago`;
      }
    }
    return 'Just now';
  };

  const filteredApplications = filter === 'all' 
    ? applications 
    : applications.filter(app => app.status === filter);

  if (loading) {
    return <div className="loading">Loading applications...</div>;
  }

  return (
    <div className="page-container">
      <div className="container">
        <h1 className="page-title">My Applications</h1>
        <p className="page-subtitle">Track the status of your job applications</p>

        <div className="applications-filters">
          <button
            className={`filter-btn ${filter === 'all' ? 'active' : ''}`}
            onClick={() => setFilter('all')}
          >
            All ({applications.length})
          </button>
          <button
            className={`filter-btn ${filter === 'pending' ? 'active' : ''}`}
            onClick={() => setFilter('pending')}
          >
            Pending ({applications.filter(a => a.status === 'pending').length})
          </button>
          <button
            className={`filter-btn ${filter === 'reviewed' ? 'active' : ''}`}
            onClick={() => setFilter('reviewed')}
          >
            Reviewed ({applications.filter(a => a.status === 'reviewed').length})
          </button>
          <button
            className={`filter-btn ${filter === 'shortlisted' ? 'active' : ''}`}
            onClick={() => setFilter('shortlisted')}
          >
            Shortlisted ({applications.filter(a => a.status === 'shortlisted').length})
          </button>
          <button
            className={`filter-btn ${filter === 'accepted' ? 'active' : ''}`}
            onClick={() => setFilter('accepted')}
          >
            Accepted ({applications.filter(a => a.status === 'accepted').length})
          </button>
        </div>

        {filteredApplications.length === 0 ? (
          <div className="no-results">
            <FileText size={64} />
            <h3>No applications found</h3>
            <p>
              {filter === 'all' 
                ? "You haven't applied to any jobs yet" 
                : `No ${filter} applications`}
            </p>
            <Link to="/jobs" className="btn btn-primary">
              Browse Jobs
            </Link>
          </div>
        ) : (
          <div className="applications-grid">
            {filteredApplications.map((application) => (
              <div key={application._id} className="application-card">
                <div className="application-header">
                  <div className="application-status-icon">
                    {getStatusIcon(application.status)}
                  </div>
                  <span className={`badge ${getStatusBadgeClass(application.status)}`}>
                    {application.status}
                  </span>
                </div>

                <Link to={`/jobs/${application.job._id}`} className="application-job-title">
                  <h3>{application.job.title}</h3>
                </Link>

                <p className="application-company">
                  <Briefcase size={16} />
                  {application.job.company}
                </p>

                <div className="application-details">
                  <div className="application-detail-item">
                    <MapPin size={16} />
                    <span>{application.job.location}</span>
                  </div>
                  <div className="application-detail-item">
                    <Clock size={16} />
                    <span>Applied {getTimeAgo(application.appliedAt)}</span>
                  </div>
                </div>

                {application.coverLetter && (
                  <div className="application-cover-letter">
                    <strong>Cover Letter:</strong>
                    <p>{application.coverLetter.substring(0, 100)}...</p>
                  </div>
                )}

                {application.notes && (
                  <div className="application-notes">
                    <strong>Employer Notes:</strong>
                    <p>{application.notes}</p>
                  </div>
                )}

                <div className="application-footer">
                  <Link to={`/jobs/${application.job._id}`} className="btn btn-secondary btn-small">
                    View Job
                  </Link>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default MyApplications;
