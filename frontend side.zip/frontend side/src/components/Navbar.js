import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Briefcase, Menu, X, User, LogOut, Home, FileText, PlusCircle } from 'lucide-react';
import './Navbar.css';

const Navbar = () => {
  const { user, logout, isAuthenticated, isEmployer } = useAuth();
  const navigate = useNavigate();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleLogout = () => {
    logout();
    navigate('/');
    setMobileMenuOpen(false);
  };

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  return (
    <nav className="navbar">
      <div className="navbar-container">
        <Link to="/" className="navbar-logo">
          <Briefcase size={28} />
          <span>JobPortal</span>
        </Link>

        <button className="mobile-menu-btn" onClick={toggleMobileMenu}>
          {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>

        <div className={`navbar-menu ${mobileMenuOpen ? 'active' : ''}`}>
          <Link to="/" className="nav-link" onClick={() => setMobileMenuOpen(false)}>
            <Home size={18} />
            <span>Home</span>
          </Link>
          
          <Link to="/jobs" className="nav-link" onClick={() => setMobileMenuOpen(false)}>
            <Briefcase size={18} />
            <span>Jobs</span>
          </Link>

          {isAuthenticated ? (
            <>
              <Link to="/dashboard" className="nav-link" onClick={() => setMobileMenuOpen(false)}>
                <FileText size={18} />
                <span>Dashboard</span>
              </Link>

              {isEmployer && (
                <Link to="/create-job" className="nav-link" onClick={() => setMobileMenuOpen(false)}>
                  <PlusCircle size={18} />
                  <span>Post Job</span>
                </Link>
              )}

              <div className="navbar-user">
                <Link to="/profile" className="nav-link" onClick={() => setMobileMenuOpen(false)}>
                  <User size={18} />
                  <span>{user?.name}</span>
                </Link>
                <button onClick={handleLogout} className="nav-link logout-btn">
                  <LogOut size={18} />
                  <span>Logout</span>
                </button>
              </div>
            </>
          ) : (
            <div className="navbar-auth">
              <Link to="/login" className="nav-link" onClick={() => setMobileMenuOpen(false)}>
                Login
              </Link>
              <Link to="/register" className="btn btn-primary" onClick={() => setMobileMenuOpen(false)}>
                Sign Up
              </Link>
            </div>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
