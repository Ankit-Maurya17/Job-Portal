import axios from 'axios';

const API_URL = 'http://localhost:5000/api';

const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json'
  }
});

// Add token to requests
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Auth API
export const authAPI = {
  register: (userData) => api.post('/auth/register', userData),
  login: (credentials) => api.post('/auth/login', credentials),
  forgotPassword: (email) => api.post('/auth/forgotpassword', email),
  resetPassword: (data) => api.put('/auth/resetpassword', data),
  getMe: () => api.get('/auth/me'),
  updateProfile: (data) => api.put('/auth/updateprofile', data),
  updatePassword: (data) => api.put('/auth/updatepassword', data)
};

// Jobs API
export const jobsAPI = {
  getAllJobs: (params) => api.get('/jobs', { params }),
  getJobById: (id) => api.get(`/jobs/${id}`),
  createJob: (jobData) => api.post('/jobs', jobData),
  updateJob: (id, jobData) => api.put(`/jobs/${id}`, jobData),
  deleteJob: (id) => api.delete(`/jobs/${id}`),
  getEmployerJobs: () => api.get('/jobs/employer/myjobs')
};

// Applications API
export const applicationsAPI = {
  createApplication: (data) => api.post('/applications', data),
  getMyApplications: () => api.get('/applications/myapplications'),
  getAllEmployerApplications: () => api.get('/applications/employer/all'),
  getJobApplications: (jobId) => api.get(`/applications/job/${jobId}`),
  getApplicationById: (id) => api.get(`/applications/${id}`),
  updateApplicationStatus: (id, data) => api.put(`/applications/${id}/status`, data)
};

export default api;
