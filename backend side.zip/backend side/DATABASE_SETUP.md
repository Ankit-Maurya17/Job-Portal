# 📊 Database Setup Guide - Hindi/English

आपका डेटा अब परमानेंट सेव होगा! Your data will now be saved permanently!

## विकल्प 1: Local MongoDB (सबसे आसान - Recommended)

### Windows पर MongoDB Install करें:

1. **MongoDB Download करें:**
   - यहाँ जाएं: https://www.mongodb.com/try/download/community
   - Windows का version select करें
   - Download और Install करें

2. **MongoDB Service Start करें:**
   ```powershell
   # PowerShell में ये commands run करें:
   net start MongoDB
   ```

3. **Check करें कि MongoDB चल रहा है:**
   ```powershell
   mongosh
   # अगर MongoDB shell खुल जाए तो सब ठीक है
   # Exit करने के लिए: exit
   ```

4. **आपका `.env` file पहले से ही सही है:**
   ```
   MONGODB_URI=mongodb://127.0.0.1:27017/job-portal
   ```

5. **Server Start करें:**
   ```powershell
   npm run dev
   ```

✅ **बस हो गया! अब आपका data permanently save होगा!**

---

## विकल्प 2: MongoDB Atlas (Free Cloud Database)

अगर आप local MongoDB install नहीं करना चाहते:

### Step 1: Account बनाएं
1. यहाँ जाएं: https://www.mongodb.com/cloud/atlas/register
2. Free account बनाएं (Credit card की जरूरत नहीं)

### Step 2: Cluster बनाएं
1. "Create a Deployment" पर क्लिक करें
2. **FREE** tier select करें (M0 Sandbox)
3. Region select करें (Mumbai या Singapore सबसे fast होगा)
4. Cluster Name: `job-portal-cluster`
5. "Create" पर क्लिक करें

### Step 3: Database User बनाएं
1. Security → Database Access
2. "Add New Database User" क्लिक करें
3. Username: `jobportal`
4. Password: एक strong password बनाएं (याद रखें!)
5. "Add User" क्लिक करें

### Step 4: Network Access Setup
1. Security → Network Access
2. "Add IP Address" क्लिक करें
3. "Allow Access from Anywhere" select करें (0.0.0.0/0)
4. "Confirm" क्लिक करें

### Step 5: Connection String लें
1. Database → Connect
2. "Connect your application" select करें
3. Driver: Node.js, Version: 5.5 or later
4. Connection string copy करें, ऐसा दिखेगा:
   ```
   mongodb+srv://jobportal:<password>@job-portal-cluster.xxxxx.mongodb.net/?retryWrites=true&w=majority
   ```

### Step 6: .env File Update करें
`.env` file में `MONGODB_URI` को update करें:

```env
MONGODB_URI=mongodb+srv://jobportal:YOUR_PASSWORD@job-portal-cluster.xxxxx.mongodb.net/job-portal?retryWrites=true&w=majority
```

**Important:** `<password>` को अपने actual password से replace करें!

### Step 7: Server Start करें
```powershell
npm run dev
```

---

## ✅ Verification - Check करें कि सब काम कर रहा है

Server start होने पर आपको ये दिखना चाहिए:

```
✅ MongoDB Connected Successfully
💾 Database: job-portal
🔗 Host: 127.0.0.1 (या आपका Atlas cluster)
🚀 Server is running on port 5000
```

---

## 🎯 अब क्या होगा?

### पहले (Before):
- ❌ Server बंद करने पर सारा data delete हो जाता था
- ❌ In-memory database use हो रहा था

### अब (Now):
- ✅ सारे profiles permanently save होंगे
- ✅ सारी job posts permanently save होंगी
- ✅ सारे applications save होंगे
- ✅ Server बंद करके फिर start करने पर भी data रहेगा

---

## 📝 Data देखने के लिए

### Local MongoDB के लिए:
```powershell
mongosh
use job-portal
db.users.find()      # सारे users देखें
db.jobs.find()       # सारी jobs देखें
db.applications.find()  # सारे applications देखें
```

### MongoDB Atlas के लिए:
1. Atlas Dashboard पर जाएं
2. Browse Collections क्लिक करें
3. अपना data graphically देख सकते हैं

---

## 🔧 Troubleshooting

### Error: "MongoDB Connection Error"
- Check करें कि MongoDB service चल रही है
- `.env` file में `MONGODB_URI` सही है या नहीं

### Error: "Authentication failed"
- Atlas के लिए: username और password check करें
- Password में special characters हैं तो URL encode करें

### Error: "Network timeout"
- Atlas के लिए: Network Access में IP address add करें
- Internet connection check करें

---

## 💡 Tips

1. **Backup लें:** Important data का regular backup लें
2. **Atlas Free Tier:** 512MB storage free मिलता है
3. **Local Development:** Local MongoDB fastest है development के लिए
4. **Production:** Atlas use करें production के लिए

---

## 📞 Need Help?

अगर कोई problem आए तो:
1. Server logs check करें
2. MongoDB service running है check करें
3. `.env` file की settings verify करें

**Happy Coding! 🚀**
