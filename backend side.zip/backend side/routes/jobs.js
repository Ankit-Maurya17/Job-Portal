const express = require('express');
const router = express.Router();
const jobController = require('../controllers/jobController');
const { protect, authorize } = require('../middleware/auth');

// Public routes
router.get('/', jobController.getAllJobs);
router.get('/:id', jobController.getJobById);

// Protected routes - Employer only
router.post('/', protect, authorize('employer'), jobController.createJob);
router.put('/:id', protect, authorize('employer'), jobController.updateJob);
router.delete('/:id', protect, authorize('employer'), jobController.deleteJob);
router.get('/employer/myjobs', protect, authorize('employer'), jobController.getEmployerJobs);

module.exports = router;
