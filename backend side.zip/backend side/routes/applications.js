const express = require('express');
const router = express.Router();
const applicationController = require('../controllers/applicationController');
const { protect, authorize } = require('../middleware/auth');

// Job seeker routes
router.post('/', protect, authorize('jobseeker'), applicationController.createApplication);
router.get('/myapplications', protect, authorize('jobseeker'), applicationController.getMyApplications);

// Employer routes
router.get('/employer/all', protect, authorize('employer'), applicationController.getAllEmployerApplications);
router.get('/job/:jobId', protect, authorize('employer'), applicationController.getJobApplications);
router.put('/:id/status', protect, authorize('employer'), applicationController.updateApplicationStatus);

// Common routes
router.get('/:id', protect, applicationController.getApplicationById);

module.exports = router;
