# ✅ Database Setup Checklist - Step by Step

## 🎯 Follow करें (सिर्फ 5 मिनट):

### ☐ Step 1: MongoDB Atlas Account बनाएं
- [ ] https://www.mongodb.com/cloud/atlas/register खोलें
- [ ] Google या Email से sign up करें (FREE)
- [ ] Email verify करें

### ☐ Step 2: Free Cluster Create करें
- [ ] "Create a Deployment" पर क्लिक करें
- [ ] **M0 FREE** tier select करें
- [ ] Region: **Mumbai** या **Singapore** select करें
- [ ] Cluster name: `job-portal`
- [ ] "Create" button क्लिक करें
- [ ] Wait करें (2-3 minutes लगेंगे)

### ☐ Step 3: Database User बनाएं
- [ ] Left menu में "Database Access" क्लिक करें
- [ ] "Add New Database User" क्लिक करें
- [ ] Username: `admin` type करें
- [ ] Password: `admin123` type करें (या कोई strong password)
- [ ] **Password याद रखें या लिख लें!** 📝
- [ ] "Add User" क्लिक करें

### ☐ Step 4: Network Access Setup करें
- [ ] Left menu में "Network Access" क्लिक करें
- [ ] "Add IP Address" क्लिक करें
- [ ] "Allow Access from Anywhere" select करें
- [ ] "Confirm" क्लिक करें

### ☐ Step 5: Connection String Copy करें
- [ ] Left menu में "Database" क्लिक करें
- [ ] "Connect" button क्लिक करें
- [ ] "Drivers" option select करें
- [ ] Driver: **Node.js** select करें
- [ ] Connection string **copy** करें
- [ ] String कुछ ऐसी होगी:
  ```
  mongodb+srv://admin:<password>@job-portal.xxxxx.mongodb.net/?retryWrites=true&w=majority
  ```

### ☐ Step 6: .env File Update करें
- [ ] `backend side/.env` file खोलें
- [ ] `MONGODB_URI` line को ढूंढें
- [ ] पुरानी line को delete करें
- [ ] नई connection string paste करें
- [ ] `<password>` को अपने actual password से replace करें
- [ ] `/job-portal` database name add करें
- [ ] Final string ऐसी दिखनी चाहिए:
  ```
  MONGODB_URI=mongodb+srv://admin:admin123@job-portal.xxxxx.mongodb.net/job-portal?retryWrites=true&w=majority
  ```
- [ ] File **save** करें (Ctrl+S)

### ☐ Step 7: Server Start करें
- [ ] Terminal खोलें
- [ ] Backend folder में जाएं:
  ```powershell
  cd "c:\Users\stc\Desktop\New folder\backend side"
  ```
- [ ] Server start करें:
  ```powershell
  npm run dev
  ```

### ☐ Step 8: Verify करें
- [ ] Terminal में ये दिखना चाहिए:
  ```
  ✅ MongoDB Connected Successfully
  💾 Database: job-portal
  🔗 Host: job-portal.xxxxx.mongodb.net
  🚀 Server is running on port 5000
  ```
- [ ] अगर ये दिख रहा है तो **सब perfect है!** 🎉

---

## 🧪 Test करें:

### ☐ Test 1: Profile Create करें
- [ ] Frontend खोलें
- [ ] New profile/user create करें
- [ ] Details fill करें और save करें

### ☐ Test 2: Server Restart करें
- [ ] Terminal में `Ctrl+C` press करें (server stop होगा)
- [ ] फिर से `npm run dev` run करें (server start होगा)

### ☐ Test 3: Data Check करें
- [ ] Login करें same credentials से
- [ ] अगर login हो गया तो **data save हो गया!** ✅
- [ ] MongoDB Atlas dashboard पर भी check कर सकते हैं

---

## 🎉 Success Criteria:

✅ Server start हो रहा है without errors  
✅ "MongoDB Connected Successfully" दिख रहा है  
✅ Profile create हो रहा है  
✅ Server restart के बाद भी data रह रहा है  

---

## ❌ अगर Error आए:

### Error: "MongoServerError: bad auth"
**Fix:**
- [ ] `.env` में username और password check करें
- [ ] Password में special characters हैं तो URL encode करें
- [ ] Atlas में user create किया है check करें

### Error: "Could not connect to any servers"
**Fix:**
- [ ] Internet connection check करें
- [ ] Network Access में IP address add है check करें
- [ ] Connection string सही copy किया है check करें

### Error: "MONGODB_URI is not defined"
**Fix:**
- [ ] `.env` file save किया है check करें
- [ ] `.env` file `backend side` folder में है check करें
- [ ] Server restart करें

---

## 📞 Help Files:

अगर कोई problem हो तो ये files पढ़ें:

1. **Quick Guide:** `QUICK_START_DATABASE.md`
2. **Detailed Guide:** `DATABASE_SETUP.md`
3. **Hindi Summary:** `README_DATABASE_HI.md`
4. **Changes Summary:** `../CHANGES_SUMMARY.md`

---

## 💡 Pro Tips:

- ✅ Password simple रखें initially (testing के लिए)
- ✅ Connection string को carefully copy करें
- ✅ `.env` file save करना न भूलें
- ✅ Server restart करें after changing `.env`
- ✅ Atlas dashboard पर data देख सकते हैं

---

## 🎯 Final Checklist:

- [ ] MongoDB Atlas account बना लिया
- [ ] Free cluster create कर लिया
- [ ] Database user add कर लिया
- [ ] Network access configure कर लिया
- [ ] Connection string copy कर लिया
- [ ] `.env` file update कर लिया
- [ ] Server successfully start हो रहा है
- [ ] Database connection successful है
- [ ] Test profile create किया
- [ ] Server restart के बाद data रहा

---

## 🚀 आप तैयार हैं!

सभी checkboxes ✅ हो गए? 

**Congratulations! 🎉**

अब आपका data permanently save होगा!  
Server बंद करने पर भी data safe रहेगा!  
Production-ready database setup हो गया!  

**Happy Coding! 💻✨**
