# 🚀 Quick Start - Database Setup (5 मिनट में)

## सबसे आसान तरीका: MongoDB Atlas (Free Cloud Database)

MongoDB install करने की जरूरत नहीं! बस ये steps follow करें:

### Step 1: Account बनाएं (2 मिनट)
1. खोलें: https://www.mongodb.com/cloud/atlas/register
2. Google/Email से sign up करें (FREE है, credit card नहीं चाहिए)

### Step 2: Free Cluster बनाएं (1 मिनट)
1. "Create a Deployment" → **M0 FREE** select करें
2. Provider: AWS
3. Region: **Mumbai (ap-south-1)** या Singapore select करें
4. Cluster Name: `job-portal`
5. "Create" button क्लिक करें

### Step 3: Database User बनाएं (30 seconds)
1. Security → Database Access → "Add New Database User"
2. Username: `admin`
3. Password: `admin123` (या कोई भी strong password)
4. "Add User" क्लिक करें

### Step 4: Network Access (30 seconds)
1. Security → Network Access → "Add IP Address"
2. "Allow Access from Anywhere" select करें
3. "Confirm" क्लिक करें

### Step 5: Connection String Copy करें (1 मिनट)
1. Database → "Connect" button क्लिक करें
2. "Drivers" select करें
3. Connection string copy करें

### Step 6: .env File Update करें

अपनी `.env` file खोलें और `MONGODB_URI` को replace करें:

**पहले:**
```env
MONGODB_URI=mongodb://127.0.0.1:27017/job-portal
```

**अब (अपना connection string paste करें):**
```env
MONGODB_URI=mongodb+srv://admin:admin123@job-portal.xxxxx.mongodb.net/job-portal?retryWrites=true&w=majority
```

⚠️ **Important:** 
- `admin123` को अपने password से replace करें
- `xxxxx` automatically आपके cluster का होगा

### Step 7: Server Start करें

```powershell
npm run dev
```

### ✅ Success! आपको ये दिखेगा:

```
✅ MongoDB Connected Successfully
💾 Database: job-portal
🔗 Host: job-portal.xxxxx.mongodb.net
🚀 Server is running on port 5000
```

---

## 🎉 बस हो गया! अब:

✅ आपके सारे profiles save होंगे  
✅ सारी job posts save होंगी  
✅ Server बंद करने पर भी data रहेगा  
✅ कहीं से भी access कर सकते हैं  

---

## 📊 अपना Data देखें

1. MongoDB Atlas Dashboard पर जाएं
2. "Browse Collections" क्लिक करें
3. अपने users, jobs, applications देखें

---

## 🔧 अगर Error आए

### "MongoServerError: bad auth"
- `.env` में username/password check करें
- Password में special characters हैं तो URL encode करें

### "Could not connect to any servers"
- Internet connection check करें
- Network Access में IP address add है check करें

### "MONGODB_URI is not defined"
- `.env` file save किया है check करें
- Server restart करें

---

## 💡 Pro Tips

1. **Free Tier:** 512MB storage free (हजारों records के लिए काफी है)
2. **Backup:** Atlas automatically backup लेता है
3. **Monitoring:** Dashboard पर real-time stats देख सकते हैं
4. **No Installation:** कोई software install नहीं करना पड़ता

---

## 📱 Example .env File

```env
PORT=5000
MONGODB_URI=mongodb+srv://admin:admin123@job-portal.ab1cd.mongodb.net/job-portal?retryWrites=true&w=majority
JWT_SECRET=your_jwt_secret_key_here_change_this_in_production_to_something_very_secure
JWT_EXPIRE=7d
NODE_ENV=development
```

---

**अब आपका project production-ready है! 🚀**
